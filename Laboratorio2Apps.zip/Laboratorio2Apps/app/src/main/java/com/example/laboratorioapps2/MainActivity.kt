/*
Sara Zavala 18893
Progrmacion de Apps
29 de Marzo 2019
App de Ejercicio
* */
package com.example.laboratorioapps2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_nueva_vuelta.*

class MainActivity : AppCompatActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var adaptador = ArrayAdapter(this,android.R.layout.simple_list_item_1, Implementacion.implementacionglobal.lapHistory)
        listaP.adapter = adaptador

        // Tomado de: https://www.android-examples.com/add-setonitemlongclicklistener-to-listview-in-android-long-press/
        listaP.onItemLongClickListener = AdapterView.OnItemLongClickListener { parent, view, position, long ->
            Toast.makeText(applicationContext,"Registro Borrado", Toast.LENGTH_SHORT).show()
            Implementacion.implementacionglobal.del(position)
            adaptador.notifyDataSetChanged()
            true
        }

    }

    fun  Siguiente(view: View) {
        val intento: Intent = Intent(this,NuevaVuelta::class.java)
        startActivity(intento)
    }

    fun eliminarHistorial(view :View){
        Implementacion.implementacionglobal.clear()
        Toast.makeText(applicationContext,"Elementos Borrados exitosamente", Toast.LENGTH_SHORT).show()
        var adaptador = ArrayAdapter(this,android.R.layout.simple_list_item_1, Implementacion.implementacionglobal.lapHistory)
        listaP.adapter = adaptador
    }


}
