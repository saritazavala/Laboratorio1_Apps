/*
Sara Zavala 18893
Progrmacion de Apps
29 de Marzo 2019
App de Ejercicio
* */
package com.example.laboratorioapps2

import android.app.Application

class Implementacion : LapHistory, Application() {
    companion object {
        var implementacionglobal:Implementacion = Implementacion()

    }
    override val lapHistory: ArrayList<Int> = ArrayList()


    override fun clear() {
        lapHistory.clear()

    }

    override fun add(element: Int) {
        lapHistory.add(element)

    }

    override fun del(elementIndex: Int) {
        lapHistory.removeAt(elementIndex)

    }


}