/*
Sara Zavala 18893
Progrmacion de Apps
29 de Marzo 2019
App de Ejercicio
* */
package com.example.laboratorioapps2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_nueva_vuelta.*
import kotlinx.android.synthetic.main.activity_nueva_vuelta.view.*

class NuevaVuelta : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nueva_vuelta)
        val valor: ArrayList<Int> = arrayListOf<Int>(1,3,5,10)
        var adapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,valor)
        lista.adapter = adapter
        lista.setOnItemClickListener  {parent, view, position : Int, id: Long ->
            var item = lista.selectedItem
            contador.text = lista.getItemAtPosition(position).toString()
        }
        }

    fun  inicio(view: View) {
        val intento: Intent = Intent(this,MainActivity::class.java)
        startActivity(intento)
    }

    fun agregarElementos(view : View){
        Toast.makeText(this, "Registro Guardado", Toast.LENGTH_LONG).show()
        Implementacion.implementacionglobal.add(contador.text.toString().toInt())
    }

    fun aumentarVueltas(view : View){
        contador.text = (contador.text.toString().toInt() + 1).toString()
    }

    fun disminuirVueltas(view: View){
        if(contador.text.toString().toInt() != 0){
            contador.text = (contador.text.toString().toInt() - 1).toString()
        }else if((contador.text.toString().toInt() == 0)) {
            Toast.makeText(this, "No puede disminuir abajo de cero", Toast.LENGTH_LONG).show()
        }

    }






}
